module.exports = (req, res, log) => {
    log("Hello world! This is the highpoint test function.");
}